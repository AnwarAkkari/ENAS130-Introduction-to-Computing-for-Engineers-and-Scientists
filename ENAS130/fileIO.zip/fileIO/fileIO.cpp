#include <iostream>
#include <fstream>
#include <iomanip>

#define FILENAMESIZE 256

using namespace std;

// Opens and reads a specified input file containing data pairs.
// The number of pairs do not need to be known ahead of time,
// because the code uses peek() to see whether EOF is coming up next.
// Writes the pairs to another file using a specified format.

// Note about the two input files:
// inputGood.dat and inputBad.dat are the same, except that inputBad.dat
// has an extra space after the very last number in the file.

int main()
{

    // Declarations and initializations
    int nPts = 0;
    float x,y;
    char inputFilename[FILENAMESIZE], outputFilename[FILENAMESIZE];

    ifstream inputFile;	 // create object in the ifstream (input file stream) class
    ofstream outputFile; // create object in the ofstream (output file stream) class

    //-----------------------------------------------------------------
    // Get name of input file and open it.
    //-----------------------------------------------------------------
    cout << "Enter the name of the input file:\n";
    cin >> inputFilename;

    inputFile.open(inputFilename); // open the file
    if (inputFile.fail())
    {
        cout << "Can't open file: "<< inputFilename << endl;
        return 1;
    }

    //-----------------------------------------------------------------
    // Get name of output file and open it.
    //-----------------------------------------------------------------
    cout << "Enter the name of the output file:\n";
    cin >> outputFilename;

    outputFile.open(outputFilename); // open the file
    if (outputFile.fail())
    {
        cout << "Can't open file: " << outputFilename << endl;
        return 1;
    }

    //-----------------------------------------------------------------
    // Read data from input file and write to output file.
    //-----------------------------------------------------------------
    cout << "Reading from " << inputFilename << "...\n";

    // Set the format in which data will be written to the output file.
    outputFile << fixed << setprecision(2);

    // The peek function checks to see if the next read would encounter an EOF.
    while (inputFile.peek() != EOF)
    {
        inputFile >> x >> y;
        outputFile << setw(6) << x << " " << setw(6) << y << endl;
        nPts++;
    }

    // Here is an alternate way to write the while loop.  It has been commented out.
    //
    // while (true) // always true...
    // {
    //     inputFile >> x >> y;
    //     if (inputFile.fail()) break;
    //     outputFile << setw(6) << x << " " << setw(6) << y << endl;
    //     nPts++;
    // }

    cout << nPts << " pairs were read in and written out.\n";

    //-----------------------------------------------------------------
    // Close the files.
    //-----------------------------------------------------------------
    inputFile.close();
    outputFile.close();

    return 0;
}
