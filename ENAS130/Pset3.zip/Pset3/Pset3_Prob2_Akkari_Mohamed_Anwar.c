// This is a program that uses a Switch statement and functions to print a menu and execute the selected function.
#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void prime(int n);
void absolute (float t);
void average (float x,float y,float z);
int main() {
    int n;
    float t,x,y,z;
    char option;
    printf("What function would you like to run: (1, 2, 3, 4): ");
    scanf("%c", &option);
    switch(option)
    {
        case '1': //Function 1 determines whether a number is prime or composite
            printf ("Enter a Natural Number:\n"); // Prompt the user to enter a number
            scanf ("%i",&n);
            prime(n);
            break;
        case '2': //Function 2 determines the absolute value of a number
            printf ("Enter Any Number:\n"); // Prompt the user to enter a number
            scanf ("%f",&t);
            absolute(t);
            break;
        case '3': //Function 3 determines the average of three numbers
            printf ("Enter Three Number:\n"); // Prompt the user to enter a number
            scanf ("%f %f %f",&x,&y,&z);
            average(x,y,z);
            break;
        case '4':
            perror("You Entered 4. Program Ended");
            exit(0);
            break;
        // Choice doesn't match any of the options (1,2,3,4) /
        default:
            printf("Error! Number is Not in the List. Try Again !");
    }
    return 0;
}

void prime(int n) {

    if (n < 0) // Test for invalid numbers
    {
        printf("You entered %i, which is invalid.\n", n);
    }

    int divisor = 0;
    for (int i = 1; i <= n; i++) // Determine the number of divisors a given number has
    {
        if(n%i == 0)
        divisor = divisor + 1;
    }

    if (divisor == 2) // If a number has two divisors, it is a prime number
    {
        printf ("You entered %i, which is prime.\n", n);
    }

    else // More than two divisors means it is a composite number
    {
        printf ("You entered %i, which is composite.\n", n);
    }
}

void absolute (float x){

    if (x >= 0)
    {
        printf ("The absolute value of %0.3f, is %0.3f.\n", x, x);
    }
    if (x < 0)
    {
        printf ("The absolute value of %0.3f, is %0.3f.\n", x, -x);
    }
}

void average (float x, float y, float z){
    printf("The average of the three numbers is: %0.3f.\n", ((x+y+z)/3));
}