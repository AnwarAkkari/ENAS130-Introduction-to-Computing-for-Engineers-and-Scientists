// This is a program that calculates standard deviation for a sample of numbers
#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define MAX          1000 // Set an arbitrary maximum allocated for data.
#define Data_File    "pset3_problem1_data.dat" // Create a constant that refers to the name of the file containing the data.
                                              // This can be done differently if we want the user to prompt the user to pick a file to analyze

int main()
{
    double Data_Table[MAX]; // Define table to store the dtat points in the .dat file
    int count = 0;
    int i = 0;

    /* Read the Data File */
    FILE *file;
    file = fopen(Data_File,"r"); // Read the .dat file which is named Data_File now
    if(!file)
    {
        perror("Error Opening File. Try Again !"); // perror is used to display a message in case of error where the file is empty
        return 1;
    }

    /* Check for the end of file to avoid memory corruption */
    memset(Data_Table, 0, sizeof(Data_Table)); // Allocate just enough memory for the table
    while (!feof(file) &&(count < MAX))
    {
        fscanf(file, "%lf", &(Data_Table[count++]));
    }

    /* Print everything in the table to check if every data point is Read
    printf("Data Points Count: %d\n", count);
    for(i = 0; i < count; i++)
    {
        printf("Data Table[%d] = %3f\n", i, Data_Table[i]);
        }
        return 0;
    */

    float sum, mean, sigma = 0; // Declare necessary variable for calculating the standard deviation and set everything to zero

    /* Calculate the Mean */
    for (int j = 0; j < count; j++)
    {
        sum = sum + Data_Table[j];
    }

    int N = count - 1;
    // printf("Number of Data Points = %i\n", N);
    // printf("Sum = %.3f\n", sum);

    mean = sum/N;
    // printf("Mean = %.3f\n", mean);

    /* Calculate the Standard Deviation */
    for (int k = 0; k < N; k++)
        sigma += pow(Data_Table[k] - mean, 2);

    sigma = sqrt(sigma / N);
    printf("Standard Deviation = %.3f\n", sigma);

    free(file);
    fclose(file);

    return 0;
}