// This is a program that uses structs to read data form a .dat file and perform a number of calculations (distance)

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>

#define MAX       1000 // Set an arbitrary maximum allocated for data.
#define Data_File "pset4_problem2_data.dat" // Create a constant that refers to the name of the file containing the data.
#define M_PI   3.14159265358979323846264338327950288

struct coordinates
{
 float latitude1;
 float longitude1;
 float latitude2;
 float longitude2;
 float distance;
};

int main()
{
    float Data_Table[MAX]; // Define table to store the dtat points in the .dat file
    int count = 0;

    // Read the Data File
    FILE *file;
    file = fopen(Data_File,"r"); // Read the .dat file which is named Data_File now
    if(!file)
    {
        perror("Error Opening File. Try Again !"); // perror is used to display a message in case of error where the file is empty
        return 1;
    }

    // Check for the end of file to avoid memory corruption
    memset(Data_Table, 0, sizeof(Data_Table)); // Allocate just enough memory for the table
    while (!feof(file) &&(count < MAX))
    {
        fscanf(file, "%f", &(Data_Table[count++]));
    }

struct coordinates Lat_long;  // Allocating memory

float r = 3958.8; // Raidus of the Earth in miles
int Total_Lines = count/4;
for (int Line = 0; Line<Total_Lines; Line++)
   {
    // placing the coordinates in a struct line by line
    Lat_long.latitude1 = Data_Table [0 + Line * 4];
    Lat_long.longitude1 = Data_Table [1 + Line * 4];
    Lat_long.latitude2 = Data_Table [2 + Line * 4];
    Lat_long.longitude2 = Data_Table [3 + Line * 4];

    printf("Coordinates: %.4f° %.4f° %.4f° %.4f°\n",Lat_long.latitude1,Lat_long.longitude1,Lat_long.latitude2,Lat_long.longitude2);

    // Convert form degrees to radians
    Lat_long.latitude1 = M_PI*(Lat_long.latitude1)/180;
    Lat_long.longitude1 = M_PI*(Lat_long.longitude1)/180;
    Lat_long.latitude2 = M_PI*(Lat_long.latitude2)/180;
    Lat_long.longitude2 = M_PI*(Lat_long.longitude2)/180;

    // Apply Haversine Formula to calculate the distance
    Lat_long.distance = 2*r*asin(sqrt(pow((sin((Lat_long.latitude1-Lat_long.latitude2)/2)),2)+cos(Lat_long.latitude1)*cos(Lat_long.latitude2)*pow(sin((Lat_long.longitude1-Lat_long.longitude2)/2),2)));

    printf("Distance: %.2f miles\n", Lat_long.distance);
   }
}

