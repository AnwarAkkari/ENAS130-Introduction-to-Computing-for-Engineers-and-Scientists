// This is a program that calculates distance between two point charges and the electrostatic force
#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define MAX         1000 // Set an arbitrary maximum allocated for data.
#define Data_File   "pset4_problem1_data.dat" // Create a constant that refers to the name of the file containing the data.
                                              // This can be done differently if we want the user to prompt the user to pick a file to analyze

int main()
{
    double Data_Table[MAX]; // Define table to store the dtat points in the .dat file
    int count = 0;
    int i = 0;

    // Read the Data File
    FILE *file;
    file = fopen(Data_File,"r"); // Read the .dat file which is named Data_File now
    if(!file)
    {
        perror("Error Opening File. Try Again !"); // perror is used to display a message in case of error where the file is empty
        return 1;
    }

    // Check for the end of file to avoid memory corruption
    memset(Data_Table, 0, sizeof(Data_Table)); // Allocate just enough memory for the table
    while (!feof(file) &&(count < MAX))
    {
        fscanf(file, "%lf", &(Data_Table[count++]));
    }

double X1, Y1, Z1, X2, Y2, Z2, Q1, Q2; // Declare all variables relevant to calculating the electric force
double k = 9000000000; // Set the Coulomb constant

count = count - 1; // Determine the total number of variables read
// printf("%i\n",count); // Print the number to check

int Total_Lines = count/8; // Determine the number of lines. How many computations for distance and force dp we need to do?
// printf("%i\n",Total_Lines); // Print the number to check against the .dat file

for (int Line = 0; Line < Total_Lines; Line++) // Go through the data line by line (a period is 8 variables)
    {
        X1 = Data_Table[0 + Line*8];
        // printf("%.1f ", X1);
        Y1 = Data_Table[1 + Line*8];
        // printf("%.1f ", Y1);
        Z1 = Data_Table[2 + Line*8];
        // printf("%.1f ", Z1);
        X2 = Data_Table[3 + Line*8];
        // printf("%.1f ", X2);
        Y2 = Data_Table[4 + Line*8];
        // printf("%.1f ", Y2);
        Z2 = Data_Table[5 + Line*8];
        // printf("%.1f ", Z2);
        Q1 = Data_Table[6 + Line*8];
        // printf("%f ", Q1);
        Q2 = Data_Table[7 + Line*8];
        // printf("%f ", Q2);

        double Distance = sqrt(pow((X2-X1), 2) + pow((Y2-Y1), 2) + pow((Z2-Z1),2)); // Determine the distance using the pythagorean theorem
        double Force = k*(Q1*Q2)/Distance; // Determine Fe based on Coulomb's law

        printf("Electric Force, Fe = %fN; The Distance Between the Two Points = %.1fm\n", Force, Distance); // Print the results each time.

    fclose(file);
    }
}