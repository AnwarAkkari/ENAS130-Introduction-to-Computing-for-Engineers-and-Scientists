#include <stdio.h>
#include <stdlib.h>

int main()

{
    float x1, x2, y1, y2, x; // Declare all variables (float because we can accept any real number)

    printf ("Enter lower data point in the format x1 y1:\n"); // Input 1st data point
    scanf ("%f %f", &x1, &y1);

    printf ("Enter higher data point in the format x2 y2:\n"); // input 2nd data point
    scanf ("%f %f", &x2, &y2);

    printf ("Enter Estimated temperature:\n"); // What temperature do you want to find the voltage for?
    scanf ("%f", &x);

    float y = 0;
    y = y1 + ((y2 - y1)/(x2 - x1)) * (x - x1); // Use interpolation formula

    printf("Interpolated Measurement is: %f %f\n", x, y); // Print the result (voltage) for the user

}