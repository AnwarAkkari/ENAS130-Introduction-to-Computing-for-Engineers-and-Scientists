#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, divisor; // Declare variables

    printf ("Input a natural number. If you want to end the program, enter -1 \n"); // Prompt the user to enter a number
    scanf ("%i",&n);

    if (n == -1) // Check if user wants to end the program
    {
        printf("Program ended\n");
        return 1;
    }

    if (n < -1) // Test for invalid numbers
    {
        printf("You entered %i, which is invalid.\n", n);
        return 2;
    }

    divisor = 0;
    for (int i = 1; i <= n; i++) // Determine the number of divisors a given number has
    {
        if(n%i == 0)
        divisor = divisor + 1;
    }

    if (divisor == 2) // If a number has two divisors, it is a prime number
    {
        printf ("You entered %i, which is prime.\n", n);
    }

    else // More than two divisors means it is a composite number
    {
        printf ("You entered %i, which is composite.\n", n);
    }
    return 0;
}

