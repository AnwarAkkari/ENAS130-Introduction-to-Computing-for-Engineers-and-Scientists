#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define MAX 1000 // Set an arbitrary maximum allocated for data.

struct Vector
{
 double x;
 double y;
 double z;
};

int main()
{
    double vecLength(Vector);
    int indexOfMinLength(Vector*, int);
    int indexOfMaxLength(Vector*, int);
 
// Prompt for and get the name of the input file.
    printf("Type the name of the input data file: ");
    scanf("%s", Data_File);

    double Data_Table[MAX]; // Define table to store the dtat points in the .dat file

    // Read the Data File
    FILE *file;
    file = fopen(Data_File,"r"); // Read the .dat file which is named Data_File now
    if(!file)
    {
        perror("Error Opening File. Try Again !"); // perror is used to display a message in case of error where the file is empty
        return 1;
    }

    int count = 0;
    // Check for the end of file to avoid memory corruption
    memset(Data_Table, 0, sizeof(Data_Table)); // Allocate just enough memory for the table
    while (!feof(file) &&(count < MAX))
    {
        fscanf(file, "%lf", &(Data_Table[count++]));
    }

    Vector arrayOfVectors [MAX];
    for (i=0; i < count; i++ ) // prevents going out of bounds when reading into the arrayOfVectors
    {
        if (fscanf(file, "%lf %lf %lf",
            &arrayOfVectors[i].x,
            &arrayOfVectors[i].y,
            &arrayOfVectors[i].z) == EOF)
            break;
    }

}


// This function returns the length of a given Vector. Remember that the length of a vector having components 𝑥,𝑦, and 𝑧
double vecLength(Vector){
 return sqrt(pow(Vector.x, 2) + pow(Vector.y, 2) + pow(Vector.z, 2));
}

//The first argument is an array of Vectors, and the second argument is an integer representing the number of (filled) entries in the array
int indexOfMinLength(VectorLengthsArray, int Nb_Entries){
 min = VectorLengthsArray[0];
 index_min = 0
 for(int i, i<Nb_Entries, i++)
 {
  if VectorLengthsArray[i] <= min
  {
   min = VectorLengthsArray[i]
   index_min = i
  }
 }
 return index_min
}

int indexOfMaxLength(Vector*, int Nb_Entries){
 max = VectorLengthsArray[0];
 index_max = 0
 for(int i, i<Nb_Entries, i++)
 {
  if VectorLengthsArray[i] >= min
  {
   max = VectorLengthsArray[i]
   index_max = i
  }
 }
 return index_max
}