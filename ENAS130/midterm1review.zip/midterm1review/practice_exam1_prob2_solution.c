#include <stdio.h>
#include <math.h>

#define ARRAYSIZE 1000
#define FILENAMESIZE 128

// Put the definition of the Vector structure before main, so that all
// functions below can see it.

typedef struct {
    double x;
    double y;
    double z;
} Vector;

int main()
{
    // Function prototypes
    double vecLength(Vector);
    int indexOfMinLength(Vector*, int);
    int indexOfMaxLength(Vector*, int);

    // Prompt for and get the name of the input file.
    char vecFilename[FILENAMESIZE];
    printf("Type the name of the input data file: ");
    scanf("%s", vecFilename);

    // Associate the file name with the appropriate file pointer variable.
    FILE *vecFile; // file pointer variable
    vecFile = fopen(vecFilename, "r"); // read from this file
    if (vecFile == NULL)
    {
        printf("Could not open input data file %s.\n", vecFilename);
        return 1;
    }

    int nVec = 0;
    // Read vector data from the input file.
    Vector arrayOfVectors[ARRAYSIZE];
    for (int i=0; i < ARRAYSIZE; i++ ) // prevents going out of bounds when reading into the arrayOfVectors
    {
        if (fscanf(vecFile, "%lf %lf %lf",
            &arrayOfVectors[i].x,
            &arrayOfVectors[i].y,
            &arrayOfVectors[i].z) == EOF)
            break;
    nVec = i; // store the total number of vectors
    }

    // Close the input file.
    fclose(vecFile);

    int min;
    int max = indexOfMaxLength(arrayOfVectors, nVec); // find the (largest) index of the longest vector
    printf("\n"); // print an empty line before the rest of the output

    // Remember that the instructions said,
    // "You do not need to re-order (or even preserve!) the values in the array."
    for (int i=0; i<nVec; i++)
    {
        // Find the index of the shortest vector.  (If there's more than one, find the largest index.)
        min = indexOfMinLength(arrayOfVectors, nVec);
        printf("Vector (%4.1lf,%4.1lf,%4.1lf) has length %7.3lf\n",
            arrayOfVectors[min].x, arrayOfVectors[min].y, arrayOfVectors[min].z, vecLength(arrayOfVectors[min]));

        // Now overwrite the shortest vector (the one we just printed) with the longest one.
        arrayOfVectors[min]= arrayOfVectors[max];
    }
    // When the for loop is complete, all the vectors in the array will have been
    // overwritten with the vector with the longest length and largest index.

    return 0;
}

// Returns the length of the vector.
double vecLength(Vector v)
{
    return sqrt(v.x*v.x + v.y*v.y + v.z*v.z);
}

// Returns the index of the vector in the array that has the minimum length.
// If there are two or more vectors of the minimum length, this function returns the largest index.
// The two arguments are the array and the number of vectors in the array.

// NOTE: To demonstrate one way of writing an array in a function header, I've used the [] notation.
//       See the indexOfMaxLength function for a different way.
int indexOfMinLength(Vector array[], int nvec)
{
    int index = 0;
    double minLength;

    minLength = vecLength(array[0]);
    for (int i=1; i<nvec; i++)
    {
        if (minLength >= vecLength(array[i])) // use of '>=' makes sure that the largest index will be returned
        {
            index = i;
            minLength = vecLength(array[i]);
        }
    }

    return index;
}

// Returns the index of the vector in the array that has the maximum length.
// If there are two or more vectors of the maximum length, this function returns the largest index.
// The two arguments are the array and the number of vectors in the array.

// NOTE: To demonstrate one way of writing an array in a function header, I've used the * notation.
//       See the indexOfMinLength function for a different way.
int indexOfMaxLength(Vector *array, int nvec)
{
    int index = 0;
    double maxLength;

    maxLength = vecLength(array[0]);
    for (int i=1; i<nvec; i++)
    {
        if (maxLength <= vecLength(array[i])) // use of '<=' makes sure that the largest index will be returned
        {
            index = i;
            maxLength = vecLength(array[i]);
        }
    }

    return index;
}
