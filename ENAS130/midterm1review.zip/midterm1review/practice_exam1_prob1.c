#include <stdio.h>

int main()
{
    int numerator = 8, denominator = 16;
    double fraction; // declare fraction as a double
    fraction = numerator/denominator;
    printf("%f\n", fraction); // reads into a double
    printf("The fraction is equal to %lf.\n", fraction);
    int x; // do not explain
    int array[4] = {10, 15, 40, 100}; //
    int *pa; // declare a pointer to an integer
    pa = array; // Thr pointer pa now refers to the memory allocation of "array". Since no element of the array is specified, pa refers to array[0]
    x = array[3];// Assign x to be the value stored in array[3].
    x = *pa+3; // x = array[0]+3 = 10 + 3 = 13
    // Finally print the value of x.
    printf("The value of x is %d.\n", x);

    return 0;
}