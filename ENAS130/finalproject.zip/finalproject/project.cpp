#include <iostream>
#include <math.h>
#include <cstring>
#include <fstream>
#include <string.h>
#include <vector>
#include <sstream>
using namespace std;

#define MAX       1000 // Set an arbitrary maximum allocated for data.
#define Data_File "DFT.dat" // Create a constant that refers to the name of the file containing the data.

class ComplexNum {
   public:
   double real, imag;
   ComplexNum() {
      real = 0.0f;
      imag = 0.0f;
   }
};

int main()
{
    double Data_Table[MAX]; // Define table to store the dtat points in the .dat file
    int count = 0;

    FILE *file; // Read the Data File
    file = fopen(Data_File,"r"); // Read the .dat file which is named Data_File now

    if(!file)
    {
        perror("Error Opening File. Try Again !"); // perror is used to display a message in case of error where the file is empty
        return 1;
    }

    // Check for the end of file to avoid memory corruption
    while (!feof(file) &&(count < MAX))
    {
        fscanf(file, "%lf", &(Data_Table[count++]));
    }

   double x[MAX];
   for (int n = 0; n<count; n++)
   {
      x[n] = Data_Table[n];
      //cout<< "Data [" << n << "] = " << x[n] << "\n>";
   }

   int M[MAX];
   int NbLines = 0, sp=0;
   string line;
   ifstream f(Data_File); // Creating input filestream
   while (getline(f, line))
        {
        NbLines++;
        sp = line.find(" ");
        string NbSamples = line.substr(0,sp);
        int obj = stoi(NbSamples);
        M[NbLines] = obj;
        }
        //cout << "Numbers of lines in the file : " << NbLines << endl;

    for (int i = 1; i <= NbLines; i++) // Arrange a matrix containing the number of samples for each row
        {
        M[i - 1] = M[i];
        }

    ofstream myfile;
    myfile.open ("project.txt");

    double outreal[MAX], outimag[MAX], a[MAX], b[MAX];
    ComplexNum outX;
    int BigN;

    int pos = count + 1;
    for (int i = 0; i < NbLines; i++)
       {
       BigN = M[NbLines - i - 1];
       pos = pos - BigN - 1;

       cout<<"This is Line "<<NbLines-i<<" in the DFT.dat file. It has "<<BigN<<" input elements. The corresponding input elements x[n] are: "<<endl;
       myfile<<"This is Line "<<NbLines-i<<" in the DFT.dat file. It has "<<BigN<<" input elements. The corresponding input elements x[n] are: "<<endl;

       cout<<"[";
       myfile<<"[";

       for (int k = 0; k < BigN; k++)
           {
               cout<<x[pos+k]<<",";
		       myfile<<x[pos+k]<<",";
           }

        cout << "--]"<< endl;
        myfile <<"--]"<< endl;

        cout << endl;
        myfile << endl;
        }

    cout << endl;
    myfile << endl;

    pos = count + 1;
    for (int i = 0; i < NbLines; i++)
       {
       BigN = M[NbLines - i - 1];
       pos = pos - BigN - 1;

       cout<<"This is Line "<<NbLines-i<<" in the DFT.dat file. It has "<<BigN<<" input elements. The corresponding DFT elements X[k] are: "<<endl;
       myfile<<"This is Line "<<NbLines-i<<" in the DFT.dat file. It has "<<BigN<<" input elements. The corresponding DFT elements X[k] are: "<<endl;

       cout<<"[";
       myfile<<"[";

        for (int k = 0; k < BigN; k++) // For each output element
           {
           double sumreal = 0.0;
           double sumimag = 0.0;
           for (int n = 0; n < BigN; n++) // For each input element
                {
                double angle = 2 * M_PI * n * k / double(BigN);
                //cout<< "angle[" << n << "] = " << angle << "\n>";
                //cout<<x[pos+n]<<",";
                sumreal +=  x[pos+n] * cos(angle);
                sumimag += -x[pos+n] * sin(angle);
                }
		    outX.real = sumreal;
		    a[k] = lround(outX.real);
		    outX.imag = sumimag;
		    b[k] = lround(outX.imag);

		    cout<< a[k] << "+j("<<b[k]<<"), ";
		    myfile<< a[k] << "+j("<<b[k]<<"), ";
            }

   cout << "--]"<< endl;
   myfile <<"--]"<< endl;

   cout << endl;
   myfile << endl;
   }

cout << endl;
myfile << endl;

pos = count+1;
for (int i = 0; i < NbLines; i++)
       {
       BigN = M[NbLines - i - 1];
       pos = pos - BigN - 1;

       cout<<"This is Line "<<NbLines-i<<" in the DFT.dat file. It has "<<BigN<<" input elements. The corresponding DFT elements magnitudes |X[k]| are: "<<endl;
       myfile<<"This is Line "<<NbLines-i<<" in the DFT.dat file. It has "<<BigN<<" input elements. The corresponding DFT elements magnitudes |X[k]| are: "<<endl;

       cout<<"[";
       myfile<<"[";

       for (int k = 0; k < BigN; k++) // For each output element
           {
           double sumreal = 0.0;
           double sumimag = 0.0;
           for (int n = 0; n < BigN; n++) // For each input element
                {
                double angle = 2 * M_PI * n * k / double(BigN);
                //cout<< "angle[" << n << "] = " << angle << "\n>";
                //cout<<x[pos+n]<<",";
                sumreal +=  x[pos + n] * cos(angle);
                sumimag += -x[pos + n] * sin(angle);
                }
		outX.real = sumreal;
		a[k] = lround(outX.real);
		outX.imag = sumimag;
		b[k] = lround(outX.imag);

        cout<< sqrt(pow(a[k],2) + pow(b[k],2))<<", ";
        myfile << sqrt(pow(a[k],2) + pow(b[k],2))<<", ";
        }

    cout << "--]" << endl;
    myfile << "--]" << endl;

    cout << endl;
    myfile << endl;
    }

myfile.close();

}
