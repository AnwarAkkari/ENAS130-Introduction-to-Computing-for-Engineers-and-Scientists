#include <stdio.h>
#include <string.h>
#include<stdlib.h>
#include <ctype.h>

int main()
{
    int nb;
    printf("Input a number: "); // Request the entry of an integer from user
    scanf("%i", &nb); // Store the number entered
    printf("Your input is: %i \n", nb); // Display the input to the user

    if (nb % 2 == 0) {
        printf("%i is an even number.\n", nb); // Check if it's even
    }
    else {
        printf("%i is an odd number\n", nb); // if the number is not even, the number is odd
    }
    return 0;
}
