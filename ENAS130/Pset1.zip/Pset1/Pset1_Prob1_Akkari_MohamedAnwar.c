#include <stdio.h>

int main()
{
    printf("Anwar\n");
    printf("Due 11:59pm Tuesday January 28th\n");
    printf("\n");
    printf("Mechanical Engineering & Applied Physics\n");
    return 0;
}
