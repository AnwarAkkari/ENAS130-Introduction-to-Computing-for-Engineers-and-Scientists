#include <stdio.h>
#include <math.h>

int main()
{
    // Declare variables to be used
    int pennies, nickels, dimes, quarters;

    // Ask User to input the number of pennies, nickels, dimes and quarters and store the values
    printf("How Many Pennies? ");
    scanf("%i", &pennies);
    printf("How Many Nickels? ");
    scanf("%i", &nickels);
    printf("How Many Dimes? ");
    scanf("%i", &dimes);
    printf("How Many Quarters? ");
    scanf("%i", &quarters);

    // Display the breakdown of coins entered by the user
    printf("\n");
    printf("Coins Entered:\n");

    printf("%i Pennies\n", pennies);
    printf("%i Nickels\n", nickels);
    printf("%i Dimes\n", dimes);
    printf("%i Quarters\n", quarters);

    // Sum all the coin into a total number of dollars and display it to the user
    float Amount_Dollars =  0.25* quarters + 0.1 * dimes + 0.05 * nickels + 0.01 * pennies;
    printf("Total Entered: $%f\n", Amount_Dollars);

    // Convert the total dollar amount into pennies: $0.01 to facilitate calculation
    int pennies_owed = Amount_Dollars * 100;

    //Determine how many bills are returned to the customer based on the amount of coins entered
    int Twenty_Bills = pennies_owed / 2000;
    int Ten_Bills = (pennies_owed % 2000) / 1000;
    int Five_Bills = ((pennies_owed % 2000) % 1000) / 500;
    int One_Bills = (((pennies_owed % 2000) % 1000) % 500) / 100;

    // Display the breakdown of the bills dispensed to the user
    printf("\n");
    printf("Bills dispensed\n");

    printf("%i $20 Bills\n", Twenty_Bills);
    printf("%i $10 Bills\n", Ten_Bills);
    printf("%i $5 Bills\n", Five_Bills);
    printf("%i $1 Bills\n", One_Bills);
}