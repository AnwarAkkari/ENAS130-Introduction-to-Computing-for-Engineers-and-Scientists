#include <string>
#include <iostream>
#include <cmath>

using namespace std;

// Declare a class
class Lat_Long {
  public:     // Access specifier
    // Data Members
    float latitude, longitude;

    // initialize object using the constructor
    Lat_Long()
      : latitude(0.0f), longitude(0.0f)
      {
      }

    // Member Functions()
    void show (){
        cout<< "(" << latitude << "," << longitude << ")\n> ";
      }
};

int main()
 {
  //Declaring Class Object
  Lat_Long location;

  cout << "Please enter a location's Latitude:\n> ";
  cin >> location.latitude;

  cout << "Please enter a location's Longitude:\n> ";
  cin >> location.longitude;

  location.show();
}