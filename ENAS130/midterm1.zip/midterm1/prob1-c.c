#include <stdio.h>
#include <math.h>

int main()
{
    int inputInt;
    double inputFloat;
    char inputChar[5];

    FILE* inFile;
    inFile = fopen("file.dat","r");

    fscanf(inFile, "%d %lf %c", &inputInt,&inputFloat,inputChar);
}