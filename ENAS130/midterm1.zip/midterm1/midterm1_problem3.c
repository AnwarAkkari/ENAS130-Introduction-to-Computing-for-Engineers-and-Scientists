/* Exam 1 Problem 3- programming problem
 * Given Cartesian coordinates (x,y), compute the
 * Polar coordinates (r, theta). You will need to include math.h
 * NAME- Mohamed Anwar Akkari */
#include <stdio.h>
#include <math.h>
#define PI  3.14159 //declare a constant called PI that is 3.14159 (5 points)

int main()
{
    //Declare the functions prototypes
    double angle(double, double);
    double magnitude(double, double);

    //Declare global variables
    double x,y;

    // Save the value into x and y
    printf ("Enter the x-coordinate of the data point: "); // Prompt the user to enter an x
    scanf ("%lf",&x);

    printf ("Enter the y-coordinate of the data point: "); // Prompt the user to enter a y
    scanf ("%lf",&y);

    //Call the function magnitude
    double mag = magnitude(y,x);

    //Call the function angle
    double ang = angle(y,x);

    //Convert theta from radians to degrees
    ang = (180*ang)/PI;

    //Print coordinates with 2 decimal places
    printf("The Corresponding Polar Coordinates (r, theta) are: (%0.2lf, %0.2lf°)\n", mag, ang);

}

//Write the functions angle and magnitude

/* Function uses atan2 to compute the angle associated with the magnitude of a polar coordinate.*/
double angle(double y, double x)
{
    double val;
    val = atan2(y,x);
    return val;
}

/* Function computes the magnitude, r, given x and y.*/
double magnitude(double y, double x)
{
  double r;
  r = sqrt(pow(y,2)+pow(x,2));
  return r;
}



