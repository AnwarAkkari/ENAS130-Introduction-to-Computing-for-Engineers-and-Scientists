#include <stdio.h>
#include <math.h>

int main()
{
    float var = sqrt(7);
    printf("%i",(int)var);

}